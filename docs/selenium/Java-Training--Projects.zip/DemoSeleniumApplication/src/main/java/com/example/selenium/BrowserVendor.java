package com.example.selenium;

public enum BrowserVendor {
    FIREFOX,
    CHROME
}
