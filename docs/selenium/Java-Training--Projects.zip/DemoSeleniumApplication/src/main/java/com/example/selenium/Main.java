package com.example.selenium;

import net.sevecek.util.ExceptionUtils;
import net.sevecek.util.swing.SwingExceptionHandler;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.swing.*;
import java.awt.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.util.concurrent.TimeUnit;

import static com.example.selenium.Main.BrowserVendor.CHROME;
import static com.example.selenium.Main.BrowserVendor.FIREFOX;

public class Main {

    public static final String WIN_BASE_DIR_LOCATION = "C:\\Java-Training\\Selenium";
    public static final String MAC_BASE_DIR_LOCATION = "$HOME/Java-Training/Selenium";
    public static final String LINUX_BASE_DIR_LOCATION = "$HOME/Java-Training/Selenium";
    public static final String WINDOWS_EXE_SUFFIX = ".exe";
    public static final String FIREFOX_SELENIUM_CONFIG_KEY = "webdriver.gecko.driver";
    public static final String FIREFOX_WEB_DRIVER_EXE = "geckodriver";
    public static final String CHROME_SELENIUM_CONFIG_KEY = "webdriver.chrome.driver";
    public static final String CHROME_WEB_DRIVER_EXE = "chromedriver";

    private WebDriver browser;
    private JLabel label;

    public static void main(String[] args) {
        new Main().run();
    }

    private void run() {
        openGui();

        try {
            openBrowser(FIREFOX);
            openWikipediaInBrowser();
        } catch (Exception e) {
            reportError();
            throw ExceptionUtils.rethrowAsUnchecked(e);
        }

        finishOk();
    }

    private void openGui() {
        SwingExceptionHandler.install();
        SwingUtilities.invokeLater(() -> {
            JFrame mainWindow = new JFrame("DemoSeleniumApplication");
            mainWindow.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            label = new JLabel("Selenium is in progress");
            label.setHorizontalAlignment(SwingConstants.CENTER);
            Font originalFont = label.getFont();
            int size = originalFont.getSize();
            label.setFont(originalFont.deriveFont(size * 3.0F));
            mainWindow.add(label);
            mainWindow.setSize(700, 300);
            mainWindow.setLocationRelativeTo(null);
            mainWindow.setVisible(true);
        });
    }

    private void reportError() {
        SwingUtilities.invokeLater(() -> {
            label.setText("Error occurred!");
        });
    }

    private void finishOk() {
        SwingUtilities.invokeLater(() -> {
            label.setText("It worked fine!");
        });
    }

    private void openBrowser(BrowserVendor browserType) {
        String webDriverExec;
        String seleniumConfigKey;
        if (browserType == FIREFOX) {
            webDriverExec = FIREFOX_WEB_DRIVER_EXE;
            seleniumConfigKey = FIREFOX_SELENIUM_CONFIG_KEY;
        } else if (browserType == CHROME) {
            webDriverExec = CHROME_WEB_DRIVER_EXE;
            seleniumConfigKey = CHROME_SELENIUM_CONFIG_KEY;
        } else {
            throw new IllegalArgumentException(("Unknown browser " + browserType));
        }

        Path webDriverLocation = translateDriverExecPath(webDriverExec);
        System.setProperty(seleniumConfigKey, webDriverLocation.toString());

        if (browserType == FIREFOX) {
            browser = new FirefoxDriver();
        } else if (browserType == CHROME) {
            browser = new ChromeDriver();
        } else {
            throw new IllegalArgumentException(("Unknown browser " + browserType));
        }
    }

    private Path translateDriverExecPath(String webDriverExec) {
        String operatingSystem = System.getProperty("os.name").toLowerCase();
        String baseDirLocation;
        if (operatingSystem.contains("win")) {
            baseDirLocation = WIN_BASE_DIR_LOCATION;
            webDriverExec = webDriverExec + WINDOWS_EXE_SUFFIX;
        } else if (operatingSystem.contains("mac")) {
            baseDirLocation = MAC_BASE_DIR_LOCATION;
        } else if (operatingSystem.contains("nux")) {
            baseDirLocation = LINUX_BASE_DIR_LOCATION;
        } else {
            throw new AssertionError("Unsupported operating system: " + operatingSystem);
        }
        String userHomeLocation = System.getProperty("user.home");
        baseDirLocation = baseDirLocation.replace("$HOME", userHomeLocation);
        Path webDriverLocation = Paths.get(baseDirLocation).resolve(webDriverExec);
        if (!Files.exists(webDriverLocation)) {
            throw new IllegalStateException("File " + webDriverExec + " was not found in " + baseDirLocation + ".\nHave you downloaded and extracted it there?");
        }
        return webDriverLocation;
    }

    private void openWikipediaInBrowser() throws InterruptedException {
        try {

            browser.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            browser.navigate().to("https://www.wikipedia.org/");
            WebElement searchElement = browser.findElement(By.id("searchInput"));
            searchElement.sendKeys("Hello World program");
            searchElement.submit();

            waitUntilJavaScript("return document.querySelector('#History');");
            WebElement historyParagraph = browser.findElement(By.id("History"));

            Thread.sleep(10_000L);

        } finally {
            browser.close();
        }
    }

    private void waitUntilJavaScript(String script) {
        WebDriverWait wait = new WebDriverWait(browser, 60);
        wait.until(it -> {
            JavascriptExecutor javascriptExecutor = (JavascriptExecutor) it;
            Object result = javascriptExecutor.executeScript(script);
            logWaiting(result);
            return result != null;
        });
    }

    private void logWaiting(Object result) {
        System.out.print(LocalTime.now() + ": " + result);
        if (result != null) {
            System.out.print("\n             " + result.getClass().getName());
        }
        System.out.println();
    }

    public enum BrowserVendor {
        FIREFOX,
        CHROME
    }
}
